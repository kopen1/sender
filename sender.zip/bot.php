<?php

require("function.php");

/***
$f = file("result/live.txt");
$ff = file("result/ded.txt");
$liv = count($f);
$ded = count($ff);
echo "
>>>>> Result Sender [ $x ]
\e[1;32m Live : $liv
\e[1;31m Ded : $ded
";
***/




echo " My Project
1. Send Sender
2. Cek Live
";
$pi = readline (" Select Number : ");

if($pi == 1){
include("send.php");
}elseif($pi == 1){
  
}


