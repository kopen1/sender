<?php

use PHPMailer\PHPMailer\PHPMailer;
function save($file,$data){
$save = fopen($file,"a");
fwrite($save, $data);
fclose($save);
}

function send($list){
require 'vendor/autoload.php';
$mm = "user@dunhilblue.xyz";
//"user@dunhilblue.xyz";
//"reply@systemsservice.net";

$mail = new PHPMailer;
$mail->isSMTP();
$mail->SMTPDebug = 0;
$mail->Host = "smtp.gmail.com";
$mail->Port = 587;
$mail->SMTPAuth = true;
$mail->Username = $mm;
$mail->Password = "Langsing1";
$mail->setFrom($mm, "Amazon, Security Account");
$mail->setLanguage('en', '/optional/path/to/language/directory/');
$mail->addAddress($list);
$mail->Subject = "Your Account has been limited";
$a = file_get_contents("anita.html");
$a = str_replace("##email##",$list,$a);
$mail->msgHTML($a);//,__DIR__);
//$mail->addAttachment('test.txt');
//$ym = explode("@",$list);$ym = "xxxxxxx@".$ym[1];
if (!$mail->send()){
echo "\e[1;31m Error :\e[2;33m $list \n";
save("result/ded.txt",$list);
} else {
echo "\e[1;32m Success :\e[1;37m $list \n";
save("result/live.txt",$list);
}

}
 
include("cfg.php"); 
$mail = $file;
$xx = file($mail);
$x = count($xx);
$i = 306;
echo "\t Jumlah Akun : $x \n";
while($i < $x){
$list = $xx[$i];
echo "\e[1;34m [$i] -> ";
send($list);
$i++;
}

$f = file("result/live.txt");
$ff = file("result/ded.txt");
$liv = count($f);
$ded = count($ff);
echo "
>>>>> Result Sender [ $x ]
\e[1;32m Live : $liv
\e[1;31m Ded : $ded
";